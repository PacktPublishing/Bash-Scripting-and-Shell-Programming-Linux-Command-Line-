#!/bin/bash

DEBUG=false
$DEBUG || echo "Debug mode OFF."

