#!/bin/bash
# This file contains carriage returns.
echo "Hello world."
